
DROP TABLE Subscribe, Agreement, Buy, Rate, Located, Next_To, Classify, Play;
DROP TABLE Directed_Movie;
DROP TABLE Genre, Theatre, Platform;
DROP TABLE Movie_Session;
DROP TABLE Director, Audience;
DROP TABLE Users, Database_Manager;